# GuardianShe
A women's safety app which sends sos upon shaking the device along with the exact location and a custom message.

![Screenshot_20230814-232316](https://github.com/aaayushh7/GuardianShe/assets/101995061/051265e1-c563-46b6-936f-7db9655b3340)![Screenshot_20230814-232319](https://github.com/aaayushh7/GuardianShe/assets/101995061/e73e07ae-745c-4fc5-a746-ef1b7b0849f2)![Screenshot_20230814-232329](https://github.com/aaayushh7/GuardianShe/assets/101995061/13041ce2-1208-4cc2-8ee0-dc930f77cf09)![Screenshot_20230814-232438~2](https://github.com/aaayushh7/GuardianShe/assets/101995061/5dae9da9-827c-4061-b20e-e605aadf88fc)
